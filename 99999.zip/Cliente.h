#pragma once
#include <string>
#include "BuscarProductos.h"
#include "BuscarServicios.h"
#include "ControlMantenimientoPreventivo.h"
#include "RegistroEmpresa.h"
#include "Pago.h"

using namespace std;

class Cliente {
private:
    string nombreUsuario;
    string contrasena;
    string tipo;
    Cliente* siguiente; // Para la lista enlazada

    void guardarCliente() const;
    bool existeCliente(const string& nombreUsuario) const;

public:
    Cliente(const string& nombreUsuario = "", const string& contrasena = "", const string& tipo = "");
    ~Cliente();

    bool registrarCliente(); // Cambiar el tipo de retorno a bool
    bool iniciarSesion(const string& nombreUsuario, const string& contrasena); // Cambiar a no const para usar variables miembros
    string getTipo() const;
    string getNombreUsuario() const;

    Cliente* getSiguiente() const;
    void setSiguiente(Cliente* siguiente);

    void buscarProductos();
    void buscarServicios();
    void controlMantenimientoPreventivo();
    void cuentaPremium();
};
