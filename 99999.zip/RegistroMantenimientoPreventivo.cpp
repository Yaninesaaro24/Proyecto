#include "RegistroMantenimientoPreventivo.h"
#include <fstream>
#include <iostream>

using namespace std;

RegistroMantenimientoPreventivo::RegistroMantenimientoPreventivo() : frente(nullptr), fondo(nullptr) {}

RegistroMantenimientoPreventivo::~RegistroMantenimientoPreventivo() {
    while (frente != nullptr) {
        NodoServicio* temp = frente;
        frente = frente->siguiente;
        delete temp;
    }
}

void RegistroMantenimientoPreventivo::guardarServicio(const NodoServicio* servicio) const {
    ofstream outFile("mantenimiento_preventivo.txt", ios::app);
    if (outFile.is_open()) {
        outFile << servicio->nombre << " " << servicio->precio << " " << servicio->duracion << endl;
        outFile.close();
        cout << "Servicio registrado con exito.\n";
    }
    else {
        cout << "Error al registrar el servicio.\n";
    }
}

void RegistroMantenimientoPreventivo::registrar() {
    int opcion;
    cout << "Seleccione el servicio de mantenimiento preventivo:\n";
    cout << "1. Cambio de Aceite y Filtro (100-200 Bs. 30-60 minutos)\n";
    cout << "2. Revision y Relleno de Fluidos (50-100 Bs. 30-60 minutos)\n";
    cout << "3. Rotacion de Neumaticos (50-100 Bs. 30-60 minutos)\n";
    cout << "4. Alineacion y Balanceo de Neumaticos (150-300 Bs. 1-2 horas)\n";
    cout << "5. Revision de Frenos (100-200 Bs. 1-2 horas)\n";
    cin >> opcion;

    string nombre;
    switch (opcion) {
    case 1:
        nombre = "Cambio de Aceite y Filtro";
        break;
    case 2:
        nombre = "Revision y Relleno de Fluidos";
        break;
    case 3:
        nombre = "Rotacion de Neumaticos";
        break;
    case 4:
        nombre = "Alineacion y Balanceo de Neumaticos";
        break;
    case 5:
        nombre = "Revision de Frenos";
        break;
    default:
        cout << "Opcion no valida.\n";
        return;
    }

    float precio;
    int duracion;
    cout << "Ingrese el precio: ";
    cin >> precio;
    cout << "Ingrese la duracion (minutos): ";
    cin >> duracion;

    NodoServicio* nuevoServicio = new NodoServicio(nombre, precio, duracion);
    if (fondo == nullptr) {
        frente = fondo = nuevoServicio;
    }
    else {
        fondo->siguiente = nuevoServicio;
        fondo = nuevoServicio;
    }
    guardarServicio(nuevoServicio);
}

void RegistroMantenimientoPreventivo::mostrar() const {
    NodoServicio* actual = frente;
    while (actual != nullptr) {
        cout << "Nombre: " << actual->nombre << endl;
        cout << "Precio: " << actual->precio << " Bs." << endl;
        cout << "Duracion: " << actual->duracion << " minutos" << endl;
        actual = actual->siguiente;
    }
}