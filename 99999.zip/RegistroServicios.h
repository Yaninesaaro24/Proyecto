#pragma once
#include <string>

using namespace std;

class RegistroServicios {
private:
    class NodoServicio {
    public:
        string categoria;
        string subcategoria;
        string nombreServicio;
        string nombreEmpresa;
        string zona;
        string calle;
        string avenida;
        double precio;
        int anilloInicio;
        int anilloFin;
        int duracion; // En minutos
        NodoServicio* siguiente;

        NodoServicio(const string& categoria, const string& subcategoria, const string& nombreServicio, const string& nombreEmpresa,
            const string& zona, const string& calle, const string& avenida, double precio, int anilloInicio, int anilloFin, int duracion)
            : categoria(categoria), subcategoria(subcategoria), nombreServicio(nombreServicio), nombreEmpresa(nombreEmpresa),
            zona(zona), calle(calle), avenida(avenida), precio(precio), anilloInicio(anilloInicio), anilloFin(anilloFin), duracion(duracion),
            siguiente(nullptr) {}
    };

    NodoServicio* cabeza;

public:
    RegistroServicios();
    ~RegistroServicios();
    void registrar();
    void mostrar() const;
    void mostrarPorFiltro(int filtro) const;
};
