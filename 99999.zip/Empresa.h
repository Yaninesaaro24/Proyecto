#pragma once
#include <string>
#include "Pago.h"
#include "RegistroEmpresa.h"
#include "RegistroMantenimientoPreventivo.h"
#include "RegistroMantenimientoCorrectivo.h"
#include "RegistroRepuestos.h"
#include "RegistroAccesorios.h"

using namespace std;

class Empresa {
private:
    string nombreUsuario;
    bool pagoRealizado;
    bool empresaRegistrada;
    Pago pago;
    RegistroEmpresa registroEmpresa;
    RegistroMantenimientoPreventivo registroMantenimientoPreventivo;
    RegistroMantenimientoCorrectivo registroMantenimientoCorrectivo;
    RegistroRepuestos registroRepuestos;
    RegistroAccesorios registroAccesorios;
    Empresa* siguiente;

    void realizarPago();
    void registrarEmpresa();
    void registrarServicio();
    void registrarProducto();
    void mostrarServicios();
    void mostrarProductos();
    void modificarInformacion();
    void esperarEnter();

public:
    Empresa(const string& nombreUsuario = "");
    Empresa(const Empresa& other);
    Empresa& operator=(const Empresa& other);
    ~Empresa();

    void menuEmpresa();
    Empresa* getSiguiente() const;
    void setSiguiente(Empresa* siguiente);
};
