#include "RegistroMantenimientoCorrectivo.h"
#include <fstream>
#include <iostream>

using namespace std;

RegistroMantenimientoCorrectivo::RegistroMantenimientoCorrectivo() : frente(nullptr), fondo(nullptr) {}

RegistroMantenimientoCorrectivo::~RegistroMantenimientoCorrectivo() {
    while (frente != nullptr) {
        NodoServicioCorrectivo* temp = frente;
        frente = frente->siguiente;
        delete temp;
    }
}

void RegistroMantenimientoCorrectivo::guardarServicio(const NodoServicioCorrectivo* servicio) const {
    ofstream outFile("mantenimiento_correctivo.txt", ios::app);
    if (outFile.is_open()) {
        outFile << servicio->nombre << " " << servicio->precio << " " << servicio->duracion << endl;
        outFile.close();
        cout << "Servicio registrado con exito.\n";
    }
    else {
        cout << "Error al registrar el servicio.\n";
    }
}

void RegistroMantenimientoCorrectivo::registrar() {
    int opcion;
    cout << "Seleccione el servicio de mantenimiento correctivo:\n";
    cout << "1. Reemplazo de Pastillas de Freno (200-400 Bs. 1-2 horas)\n";
    cout << "2. Cambio de Amortiguadores (600-1600 Bs. 2-4 horas)\n";
    cout << "3. Reparacion de la Direccion (800-2000 Bs. 4-6 horas)\n";
    cout << "4. Reemplazo de Embrague (1500-3000 Bs. 8-16 horas)\n";
    cin >> opcion;

    string nombre;
    switch (opcion) {
    case 1:
        nombre = "Reemplazo de Pastillas de Freno";
        break;
    case 2:
        nombre = "Cambio de Amortiguadores";
        break;
    case 3:
        nombre = "Reparacion de la Direccion";
        break;
    case 4:
        nombre = "Reemplazo de Embrague";
        break;
    default:
        cout << "Opcion no valida.\n";
        return;
    }

    float precio;
    int duracion;
    cout << "Ingrese el precio: ";
    cin >> precio;
    cout << "Ingrese la duracion (minutos): ";
    cin >> duracion;

    NodoServicioCorrectivo* nuevoServicio = new NodoServicioCorrectivo(nombre, precio, duracion);
    if (fondo == nullptr) {
        frente = fondo = nuevoServicio;
    }
    else {
        fondo->siguiente = nuevoServicio;
        fondo = nuevoServicio;
    }
    guardarServicio(nuevoServicio);
}

void RegistroMantenimientoCorrectivo::mostrar() const {
    NodoServicioCorrectivo* actual = frente;
    while (actual != nullptr) {
        cout << "Nombre: " << actual->nombre << endl;
        cout << "Precio: " << actual->precio << " Bs." << endl;
        cout << "Duracion: " << actual->duracion << " minutos" << endl;
        actual = actual->siguiente;
    }
}
