#pragma once
#include <string>

using namespace std;

class Usuario {
private:
    string nombreUsuario;
    string contrasena;
    string tipo;
    Usuario* siguiente; // Apuntador para la lista enlazada

    void guardarUsuario() const;
    bool existeUsuario(const string& nombreUsuario) const;

public:
    Usuario(const string& nombreUsuario = "", const string& contrasena = "", const string& tipo = "");
    ~Usuario();

    bool registrarUsuario();
    bool iniciarSesion(const string& nombreUsuario, const string& contrasena);
    string getTipo() const;
    string getNombreUsuario() const;

    Usuario* getSiguiente() const;
    void setSiguiente(Usuario* siguiente);
};
