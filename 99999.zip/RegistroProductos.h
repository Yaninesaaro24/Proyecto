#pragma once
#include <string>

using namespace std;

class NodoProducto {
public:
    string nombre;
    float precio;
    NodoProducto* siguiente;

    NodoProducto(const string& nombre, float precio)
        : nombre(nombre), precio(precio), siguiente(nullptr) {}
};

class RegistroProductos {
private:
    NodoProducto* tope;

    void guardarProducto(const NodoProducto* producto) const;

public:
    RegistroProductos();
    ~RegistroProductos();

    void registrar();
    void mostrar() const;
};
