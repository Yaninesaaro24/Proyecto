#pragma once
#include <string>
#include "RegistroServicios.h"
#include "RegistroEmpresa.h"

using namespace std;

class BuscarServicios {
public:
    void buscar() const;
};
