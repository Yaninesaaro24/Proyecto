#pragma once
#include <string>
#include <iostream>
#include <fstream>

using namespace std;

class ControlMantenimientoPreventivo {
private:
    class Mantenimiento {
    public:
        string tipo;
        double kilometraje;
        Mantenimiento* siguiente;

        Mantenimiento(const string& tipo, double kilometraje)
            : tipo(tipo), kilometraje(kilometraje), siguiente(nullptr) {}
    };

    Mantenimiento* mantenimientos;

    void agregarMantenimiento(const string& tipo, double kilometraje);

public:
    ControlMantenimientoPreventivo();
    ~ControlMantenimientoPreventivo();

    void menuControlMantenimiento();
    void mostrarMantenimientos() const;
};
