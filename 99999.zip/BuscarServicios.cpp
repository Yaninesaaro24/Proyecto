#include "BuscarServicios.h"
#include <iostream>
#include <fstream>
#include <sstream>

using namespace std;

void BuscarServicios::buscar() const {
    ifstream archivo("servicios.txt");
    if (!archivo.is_open()) {
        cout << "No se pudo abrir el archivo de servicios." << endl;
        return;
    }

    string linea;
    while (getline(archivo, linea)) {
        stringstream ss(linea);
        string categoria, subcategoria, nombreServicio, nombreEmpresa, zona, calle, avenida;
        double precio;
        int duracion, anilloInicio, anilloFin;

        getline(ss, categoria, '|');
        getline(ss, subcategoria, '|');
        getline(ss, nombreServicio, '|');
        ss >> precio >> duracion;
        ss.ignore();
        getline(ss, nombreEmpresa, '|');
        getline(ss, zona, '|');
        ss >> anilloInicio >> anilloFin;
        ss.ignore();
        getline(ss, calle, '|');
        getline(ss, avenida);

        cout << "========================================\n";
        cout << "Categoria: " << categoria << endl;
        cout << "Subcategoria: " << subcategoria << endl;
        cout << "Servicio: " << nombreServicio << endl;
        cout << "Precio: " << precio << endl;
        cout << "Duracion: " << duracion << " minutos" << endl;
        cout << "Empresa: " << nombreEmpresa << endl;
        cout << "Ubicacion: " << zona << ", Calle " << calle << ", Avenida " << avenida << ", Anillo " << anilloInicio << "-" << anilloFin << endl;
        cout << "========================================\n";
    }

    archivo.close();
}
