#pragma once
#include <string>

using namespace std;

class Ubicacion {
private:
    string zona;
    int anilloInicio;
    int anilloFin;
    string calle;
    string avenida;

public:
    Ubicacion();
    void registrarUbicacion();
    string getZona() const;
    int getAnilloInicio() const;
    int getAnilloFin() const;
    string getCalle() const;
    string getAvenida() const;

    void setZona(const string& zona);
    void setAnilloInicio(int anilloInicio);
    void setAnilloFin(int anilloFin);
    void setCalle(const string& calle);
    void setAvenida(const string& avenida);
};
