#include "Empresa.h"
#include <iostream>
#include <fstream>
#include <sstream>
#include <limits>

using namespace std;

Empresa::Empresa(const string& nombreUsuario)
    : nombreUsuario(nombreUsuario), pagoRealizado(false), empresaRegistrada(false),
    pago(), registroEmpresa(), registroMantenimientoPreventivo(), registroMantenimientoCorrectivo(),
    registroRepuestos(), registroAccesorios(), siguiente(nullptr) {}

Empresa::Empresa(const Empresa& other)
    : nombreUsuario(other.nombreUsuario), pagoRealizado(other.pagoRealizado),
    empresaRegistrada(other.empresaRegistrada), pago(other.pago), registroEmpresa(other.registroEmpresa),
    registroMantenimientoPreventivo(other.registroMantenimientoPreventivo),
    registroMantenimientoCorrectivo(other.registroMantenimientoCorrectivo),
    registroRepuestos(other.registroRepuestos), registroAccesorios(other.registroAccesorios),
    siguiente(nullptr) {}

Empresa& Empresa::operator=(const Empresa& other) {
    if (this != &other) {
        nombreUsuario = other.nombreUsuario;
        pagoRealizado = other.pagoRealizado;
        empresaRegistrada = other.empresaRegistrada;
        pago = other.pago;
        registroEmpresa = other.registroEmpresa;
        registroMantenimientoPreventivo = other.registroMantenimientoPreventivo;
        registroMantenimientoCorrectivo = other.registroMantenimientoCorrectivo;
        registroRepuestos = other.registroRepuestos;
        registroAccesorios = other.registroAccesorios;
        siguiente = nullptr;
    }
    return *this;
}

Empresa::~Empresa() {}

void Empresa::menuEmpresa() {
    int opcion;
    while (true) {
        cout << "\n==============================\n";
        cout << "       Menu de la Empresa     \n";
        cout << "==============================\n";
        if (!pagoRealizado) {
            cout << "1. Realizar Pago de Mensualidad\n";
            cout << "2. Salir\n";
        }
        else if (!empresaRegistrada) {
            cout << "1. Registrar Empresa\n";
            cout << "2. Salir\n";
        }
        else {
            cout << "1. Registrar Producto\n";
            cout << "2. Registrar Servicio\n";
            cout << "3. Mostrar Servicios\n";
            cout << "4. Mostrar Productos\n";
            cout << "5. Modificar Informacion\n";
            cout << "6. Salir\n";
        }
        cout << "------------------------------\n";
        cout << "Seleccione una opcion: ";
        cin >> opcion;

        if (cin.fail() || (!pagoRealizado && (opcion < 1 || opcion > 2)) ||
            (pagoRealizado && !empresaRegistrada && (opcion < 1 || opcion > 2)) ||
            (pagoRealizado && empresaRegistrada && (opcion < 1 || opcion > 6))) {
            cin.clear();
            cin.ignore(numeric_limits<streamsize>::max(), '\n');
            cout << "Opcion no valida. Presione Enter para intentar de nuevo.";
            esperarEnter();
            continue;
        }

        switch (opcion) {
        case 1:
            if (!pagoRealizado) {
                realizarPago();
            }
            else if (!empresaRegistrada) {
                registrarEmpresa();
            }
            else {
                registrarProducto();
            }
            break;
        case 2:
            if (!pagoRealizado || !empresaRegistrada) {
                return;
            }
            else {
                registrarServicio();
            }
            break;
        case 3:
            mostrarServicios();
            break;
        case 4:
            mostrarProductos();
            break;
        case 5:
            modificarInformacion();
            break;
        case 6:
            return; // Salir al menu principal
        }
        esperarEnter();
    }
}

void Empresa::realizarPago() {
    if (pago.realizarPago()) {
        pagoRealizado = true;
        cout << "Pago realizado. Ahora puede registrar su empresa.\n";
    }
    else {
        cout << "Pago no realizado. No puede registrar su empresa.\n";
    }
}

void Empresa::registrarEmpresa() {
    ifstream inFile("empresas.txt");
    string linea;
    while (getline(inFile, linea)) {
        if (linea.find(nombreUsuario) != string::npos) {
            empresaRegistrada = true;
            registroEmpresa.cargarDesdeArchivo(nombreUsuario); // Usar cargarDesdeArchivo
            inFile.close();
            return;
        }
    }
    inFile.close();

    cout << "Registrar la empresa.\n";
    registroEmpresa.registrarEmpresa();
    empresaRegistrada = true;
}

void Empresa::registrarServicio() {
    int opcion;
    cout << "Seleccione el tipo de servicio:\n";
    cout << "1. Mantenimiento Preventivo\n";
    cout << "2. Mantenimiento Correctivo\n";
    cin >> opcion;
    cin.ignore();
    if (opcion == 1) {
        registroMantenimientoPreventivo.registrar();
    }
    else if (opcion == 2) {
        registroMantenimientoCorrectivo.registrar();
    }
    else {
        cout << "Opcion no valida.\n";
    }
}

void Empresa::registrarProducto() {
    int opcion;
    cout << "Seleccione el tipo de producto:\n";
    cout << "1. Repuestos\n";
    cout << "2. Accesorios\n";
    cin >> opcion;
    cin.ignore();
    if (opcion == 1) {
        registroRepuestos.registrar();
    }
    else if (opcion == 2) {
        registroAccesorios.registrar();
    }
    else {
        cout << "Opcion no valida.\n";
    }
}

void Empresa::mostrarServicios() {
    cout << "Servicios de Mantenimiento Preventivo:\n";
    registroMantenimientoPreventivo.mostrar();
    cout << "Servicios de Mantenimiento Correctivo:\n";
    registroMantenimientoCorrectivo.mostrar();
}

void Empresa::mostrarProductos() {
    cout << "Repuestos:\n";
    registroRepuestos.mostrar();
    cout << "Accesorios:\n";
    registroAccesorios.mostrar();
}

void Empresa::modificarInformacion() {
    registroEmpresa.modificarEmpresa();
}

void Empresa::esperarEnter() {
    cout << "\nPresione Enter para continuar...";
    cin.ignore(numeric_limits<streamsize>::max(), '\n');
    cin.get();
}

Empresa* Empresa::getSiguiente() const {
    return siguiente;
}

void Empresa::setSiguiente(Empresa* siguiente) {
    this->siguiente = siguiente;
}
