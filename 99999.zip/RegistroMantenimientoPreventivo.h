#pragma once
#include <string>

using namespace std;

class NodoServicio {
public:
    string nombre;
    float precio;
    int duracion;
    NodoServicio* siguiente;

    NodoServicio(const string& nombre, float precio, int duracion)
        : nombre(nombre), precio(precio), duracion(duracion), siguiente(nullptr) {}
};

class RegistroMantenimientoPreventivo {
private:
    NodoServicio* frente;
    NodoServicio* fondo;

    void guardarServicio(const NodoServicio* servicio) const;

public:
    RegistroMantenimientoPreventivo();
    ~RegistroMantenimientoPreventivo();

    void registrar();
    void mostrar() const;
};
