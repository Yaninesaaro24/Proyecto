#include "RegistroProductos.h"
#include <fstream>
#include <iostream>

using namespace std;

RegistroProductos::RegistroProductos() : tope(nullptr) {}

RegistroProductos::~RegistroProductos() {
    while (tope != nullptr) {
        NodoProducto* temp = tope;
        tope = tope->siguiente;
        delete temp;
    }
}

void RegistroProductos::guardarProducto(const NodoProducto* producto) const {
    ofstream outFile("productos.txt", ios::app);
    if (outFile.is_open()) {
        outFile << producto->nombre << " " << producto->precio << endl;
        outFile.close();
        cout << "Producto registrado con exito.\n";
    }
    else {
        cout << "Error al registrar el producto.\n";
    }
}

void RegistroProductos::registrar() {
    int opcion1, opcion2;
    cout << "Seleccione la categoria de producto:\n";
    cout << "1. Motor\n";
    cout << "2. Suspension/Direccion\n";
    cout << "3. Caja y Roster Corona Palier Cardan\n";
    cout << "4. Sistema Electrico\n";
    cout << "5. Frenos y Embrague\n";
    cout << "6. Filtros\n";
    cout << "7. Piezas de Carroceria\n";
    cout << "8. Retenes Rodamientos Crucetas y Correas\n";
    cin >> opcion1;

    switch (opcion1) {
    case 1:
        cout << "Seleccione el producto del motor:\n";
        cout << "1. Pistones (400-1200 Bs.)\n";
        cout << "2. Juntas de culata (300-800 Bs.)\n";
        break;
    case 2:
        cout << "Seleccione el producto de suspension/direccion:\n";
        cout << "1. Amortiguadores (300-800 Bs.)\n";
        cout << "2. Cremalleras de direccion (800-2000 Bs.)\n";
        break;
    case 3:
        cout << "Seleccione el producto de caja y roster corona palier cardan:\n";
        cout << "1. Ejes de transmision (Palier) (500-1500 Bs.)\n";
        cout << "2. Cardan (1000-3000 Bs.)\n";
        break;
    case 4:
        cout << "Seleccione el producto del sistema electrico:\n";
        cout << "1. Baterias (300-800 Bs.)\n";
        cout << "2. Alternadores (500-1500 Bs.)\n";
        break;
    case 5:
        cout << "Seleccione el producto de frenos y embrague:\n";
        cout << "1. Discos de freno (200-600 Bs.)\n";
        cout << "2. Pastillas de freno (100-300 Bs.)\n";
        cout << "3. Embragues (800-2000 Bs.)\n";
        break;
    case 6:
        cout << "Seleccione el producto de filtros:\n";
        cout << "1. Filtros de aire (50-150 Bs.)\n";
        cout << "2. Filtros de aceite (50-150 Bs.)\n";
        break;
    case 7:
        cout << "Seleccione el producto de piezas de carroceria:\n";
        cout << "1. Parachoques (600-2000 Bs.)\n";
        cout << "2. Faros y luces traseras (200-800 Bs.)\n";
        break;
    case 8:
        cout << "Seleccione el producto de retenes rodamientos crucetas y correas:\n";
        cout << "1. Rodamientos (100-400 Bs.)\n";
        cout << "2. Correas de distribucion (200-800 Bs.)\n";
        break;
    default:
        cout << "Opcion no valida.\n";
        return;
    }

    cin >> opcion2;
    string nombre;
    switch (opcion1) {
    case 1:
        nombre = (opcion2 == 1) ? "Pistones" : "Juntas de culata";
        break;
    case 2:
        nombre = (opcion2 == 1) ? "Amortiguadores" : "Cremalleras de direccion";
        break;
    case 3:
        nombre = (opcion2 == 1) ? "Ejes de transmision (Palier)" : "Cardan";
        break;
    case 4:
        nombre = (opcion2 == 1) ? "Baterias" : "Alternadores";
        break;
    case 5:
        if (opcion2 == 1) nombre = "Discos de freno";
        else if (opcion2 == 2) nombre = "Pastillas de freno";
        else nombre = "Embragues";
        break;
    case 6:
        nombre = (opcion2 == 1) ? "Filtros de aire" : "Filtros de aceite";
        break;
    case 7:
        nombre = (opcion2 == 1) ? "Parachoques" : "Faros y luces traseras";
        break;
    case 8:
        nombre = (opcion2 == 1) ? "Rodamientos" : "Correas de distribucion";
        break;
    default:
        cout << "Opcion no valida.\n";
        return;
    }

    float precio;
    cout << "Ingrese el precio: ";
    cin >> precio;

    NodoProducto* nuevoProducto = new NodoProducto(nombre, precio);
    nuevoProducto->siguiente = tope;
    tope = nuevoProducto;
    guardarProducto(nuevoProducto);
}

void RegistroProductos::mostrar() const {
    NodoProducto* actual = tope;
    while (actual != nullptr) {
        cout << "Nombre: " << actual->nombre << endl;
        cout << "Precio: " << actual->precio << " Bs." << endl;
        actual = actual->siguiente;
    }
}
