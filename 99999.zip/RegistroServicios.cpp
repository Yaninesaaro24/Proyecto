#include "RegistroServicios.h"
#include <iostream>
#include <fstream>
#include <sstream>
#include <limits>

using namespace std;

RegistroServicios::RegistroServicios() : cabeza(nullptr) {}

RegistroServicios::~RegistroServicios() {
    NodoServicio* actual = cabeza;
    while (actual != nullptr) {
        NodoServicio* siguiente = actual->siguiente;
        delete actual;
        actual = siguiente;
    }
}

void RegistroServicios::registrar() {
    string categoria, subcategoria, nombreServicio, nombreEmpresa, zona, calle, avenida;
    double precio;
    int anilloInicio, anilloFin, duracion;

    cout << "Ingrese la categoria del servicio: ";
    cin.ignore();
    getline(cin, categoria);
    cout << "Ingrese la subcategoria del servicio: ";
    getline(cin, subcategoria);
    cout << "Ingrese el nombre del servicio: ";
    getline(cin, nombreServicio);
    cout << "Ingrese el precio del servicio: ";
    cin >> precio;
    cout << "Ingrese la duracion del servicio (en minutos): ";
    cin >> duracion;
    cout << "Ingrese el nombre de la empresa: ";
    cin.ignore();
    getline(cin, nombreEmpresa);
    cout << "Ingrese la zona (Norte, Sur, Este, Oeste): ";
    getline(cin, zona);
    cout << "Ingrese el anillo inicial (1-12): ";
    cin >> anilloInicio;
    cout << "Ingrese el anillo final (1-12): ";
    cin >> anilloFin;
    cout << "Ingrese la calle: ";
    cin.ignore();
    getline(cin, calle);
    cout << "Ingrese la avenida: ";
    getline(cin, avenida);

    NodoServicio* nuevo = new NodoServicio(categoria, subcategoria, nombreServicio, nombreEmpresa, zona, calle, avenida, precio, anilloInicio, anilloFin, duracion);
    nuevo->siguiente = cabeza;
    cabeza = nuevo;

    ofstream archivo("servicios.txt", ios::app);
    if (archivo.is_open()) {
        archivo << categoria << "|" << subcategoria << "|" << nombreServicio << "|" << precio << "|" << duracion << "|" << nombreEmpresa << "|" << zona << "|" << anilloInicio << "|" << anilloFin << "|" << calle << "|" << avenida << "\n";
        archivo.close();
        cout << "Servicio registrado exitosamente.\n";
    }
    else {
        cout << "No se pudo abrir el archivo para guardar el servicio.\n";
    }
}

void RegistroServicios::mostrar() const {
    NodoServicio* actual = cabeza;
    while (actual != nullptr) {
        cout << "========================================\n";
        cout << "Categoria: " << actual->categoria << endl;
        cout << "Subcategoria: " << actual->subcategoria << endl;
        cout << "Servicio: " << actual->nombreServicio << endl;
        cout << "Precio: " << actual->precio << endl;
        cout << "Duracion: " << actual->duracion << " minutos" << endl;
        cout << "Empresa: " << actual->nombreEmpresa << endl;
        cout << "Ubicacion: " << actual->zona << ", Calle " << actual->calle << ", Avenida " << actual->avenida << ", Anillo " << actual->anilloInicio << "-" << actual->anilloFin << endl;
        cout << "========================================\n";
        actual = actual->siguiente;
    }
}

void RegistroServicios::mostrarPorFiltro(int filtro) const {
    ifstream archivo("servicios.txt");
    if (!archivo.is_open()) {
        cout << "No se pudo abrir el archivo de servicios." << endl;
        return;
    }

    string linea;
    while (getline(archivo, linea)) {
        stringstream ss(linea);
        string categoria, subcategoria, nombreServicio, nombreEmpresa, zona, calle, avenida;
        double precio;
        int anilloInicio, anilloFin, duracion;

        getline(ss, categoria, '|');
        getline(ss, subcategoria, '|');
        getline(ss, nombreServicio, '|');
        ss >> precio;
        ss.ignore();
        ss >> duracion;
        ss.ignore();
        getline(ss, nombreEmpresa, '|');
        getline(ss, zona, '|');
        ss >> anilloInicio >> anilloFin;
        ss.ignore();
        getline(ss, calle, '|');
        getline(ss, avenida);

        // Filtro por precio
        if (filtro == 1) {
            double precioMin, precioMax;
            cout << "Ingrese el precio minimo: ";
            cin >> precioMin;
            cout << "Ingrese el precio maximo: ";
            cin >> precioMax;

            if (precio >= precioMin && precio <= precioMax) {
                cout << "========================================\n";
                cout << "Categoria: " << categoria << endl;
                cout << "Subcategoria: " << subcategoria << endl;
                cout << "Servicio: " << nombreServicio << endl;
                cout << "Precio: " << precio << endl;
                cout << "Duracion: " << duracion << " minutos" << endl;
                cout << "Empresa: " << nombreEmpresa << endl;
                cout << "Ubicacion: " << zona << ", Calle " << calle << ", Avenida " << avenida << ", Anillo " << anilloInicio << "-" << anilloFin << endl;
                cout << "========================================\n";
            }
        }

        // Filtro por ubicaci�n
        if (filtro == 2) {
            string zonaCliente;
            int anilloCliente;
            cout << "Ingrese su zona (Norte, Sur, Este, Oeste): ";
            cin >> zonaCliente;
            cout << "Ingrese su anillo (1-12): ";
            cin >> anilloCliente;

            if (zona == zonaCliente && (anilloInicio <= anilloCliente && anilloFin >= anilloCliente)) {
                cout << "========================================\n";
                cout << "Categoria: " << categoria << endl;
                cout << "Subcategoria: " << subcategoria << endl;
                cout << "Servicio: " << nombreServicio << endl;
                cout << "Precio: " << precio << endl;
                cout << "Duracion: " << duracion << " minutos" << endl;
                cout << "Empresa: " << nombreEmpresa << endl;
                cout << "Ubicacion: " << zona << ", Calle " << calle << ", Avenida " << avenida << ", Anillo " << anilloInicio << "-" << anilloFin << endl;
                cout << "========================================\n";
            }
        }
    }

    archivo.close();
}
