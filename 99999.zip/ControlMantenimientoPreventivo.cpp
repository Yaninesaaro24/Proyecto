#include "ControlMantenimientoPreventivo.h"

ControlMantenimientoPreventivo::ControlMantenimientoPreventivo() : mantenimientos(nullptr) {}

ControlMantenimientoPreventivo::~ControlMantenimientoPreventivo() {
    while (mantenimientos != nullptr) {
        Mantenimiento* temp = mantenimientos;
        mantenimientos = mantenimientos->siguiente;
        delete temp;
    }
}

void ControlMantenimientoPreventivo::agregarMantenimiento(const string& tipo, double kilometraje) {
    Mantenimiento* nuevo = new Mantenimiento(tipo, kilometraje);
    if (mantenimientos == nullptr) {
        mantenimientos = nuevo;
    }
    else {
        Mantenimiento* temp = mantenimientos;
        while (temp->siguiente != nullptr) {
            temp = temp->siguiente;
        }
        temp->siguiente = nuevo;
    }
    ofstream outFile("mantenimientos.txt", ios::app);
    if (outFile.is_open()) {
        outFile << tipo << "|" << kilometraje << "\n";
        outFile.close();
    }
    else {
        cout << "Error al abrir el archivo de mantenimientos.\n";
    }
}

void ControlMantenimientoPreventivo::menuControlMantenimiento() {
    int opcion;
    double kilometraje;
    while (true) {
        cout << "==============================\n";
        cout << "   Control Mantenimiento Preventivo   \n";
        cout << "==============================\n";
        cout << "1. Cambio de Aceite y Filtro\n";
        cout << "2. Revision y Relleno de Fluidos\n";
        cout << "3. Rotacion de Neumaticos\n";
        cout << "4. Alineacion y Balanceo de Neumaticos\n";
        cout << "5. Revision de Frenos\n";
        cout << "6. Mostrar Mantenimientos\n";
        cout << "7. Salir\n";
        cout << "Seleccione una opcion: ";
        cin >> opcion;

        if (cin.fail() || opcion < 1 || opcion > 7) {
            cin.clear();
            cin.ignore(numeric_limits<streamsize>::max(), '\n');
            cout << "Opcion no valida. Presione Enter para intentar de nuevo.";
            cin.ignore();
            continue;
        }

        if (opcion == 7) {
            break;
        }

        if (opcion != 6) {
            cout << "Ingrese el kilometraje: ";
            cin >> kilometraje;
            if (cin.fail()) {
                cin.clear();
                cin.ignore(numeric_limits<streamsize>::max(), '\n');
                cout << "Kilometraje no valido. Presione Enter para intentar de nuevo.";
                cin.ignore();
                continue;
            }
        }

        switch (opcion) {
        case 1:
            agregarMantenimiento("Cambio de Aceite y Filtro", kilometraje);
            break;
        case 2:
            agregarMantenimiento("Revision y Relleno de Fluidos", kilometraje);
            break;
        case 3:
            agregarMantenimiento("Rotacion de Neumaticos", kilometraje);
            break;
        case 4:
            agregarMantenimiento("Alineacion y Balanceo de Neumaticos", kilometraje);
            break;
        case 5:
            agregarMantenimiento("Revision de Frenos", kilometraje);
            break;
        case 6:
            mostrarMantenimientos();
            break;
        }
    }
}

void ControlMantenimientoPreventivo::mostrarMantenimientos() const {
    ifstream inFile("mantenimientos.txt");
    if (inFile.is_open()) {
        string line;
        while (getline(inFile, line)) {
            cout << line << endl;
        }
        inFile.close();
    }
    else {
        cout << "Error al abrir el archivo de mantenimientos.\n";
    }
}
