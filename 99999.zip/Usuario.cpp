#include "Usuario.h"
#include <fstream>
#include <iostream>

Usuario::Usuario(const string& nombreUsuario, const string& contrasena, const string& tipo)
    : nombreUsuario(nombreUsuario), contrasena(contrasena), tipo(tipo), siguiente(nullptr) {}

Usuario::~Usuario() {}

bool Usuario::registrarUsuario() {
    if (existeUsuario(nombreUsuario)) {
        return false;
    }

    guardarUsuario();
    return true;
}

bool Usuario::iniciarSesion(const string& nombreUsuario, const string& contrasena) {
    ifstream inFile("usuarios.txt");
    string linea;
    while (getline(inFile, linea)) {
        size_t pos = linea.find("|");
        string usuarioArchivo = linea.substr(0, pos);
        string resto = linea.substr(pos + 1);
        pos = resto.find("|");
        string contrasenaArchivo = resto.substr(0, pos);
        string tipoArchivo = resto.substr(pos + 1);
        if (usuarioArchivo == nombreUsuario && contrasenaArchivo == contrasena) {
            this->nombreUsuario = nombreUsuario;
            this->contrasena = contrasena;
            this->tipo = tipoArchivo;
            return true;
        }
    }
    return false;
}

string Usuario::getTipo() const {
    return tipo;
}

string Usuario::getNombreUsuario() const {
    return nombreUsuario;
}

Usuario* Usuario::getSiguiente() const {
    return siguiente;
}

void Usuario::setSiguiente(Usuario* siguiente) {
    this->siguiente = siguiente;
}

void Usuario::guardarUsuario() const {
    ofstream outFile("usuarios.txt", ios::app);
    if (outFile.is_open()) {
        outFile << nombreUsuario << "|" << contrasena << "|" << tipo << endl;
        outFile.close();
    }
    else {
        cout << "Error al guardar el usuario.\n";
    }
}

bool Usuario::existeUsuario(const string& nombreUsuario) const {
    ifstream inFile("usuarios.txt");
    string linea;
    while (getline(inFile, linea)) {
        size_t pos = linea.find("|");
        string usuarioArchivo = linea.substr(0, pos);
        if (usuarioArchivo == nombreUsuario) {
            return true;
        }
    }
    return false;
}