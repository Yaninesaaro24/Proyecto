#pragma once
#include <string>
#include "Ubicacion.h"

using namespace std;

class RegistroEmpresa {
private:
    string nombre;
    string nit;
    string tipoEmpresa;
    Ubicacion ubicacion;

public:
    RegistroEmpresa();
    void registrarEmpresa();
    void mostrarEmpresa() const;
    void modificarEmpresa();
    void guardarEnArchivo() const;
    bool cargarDesdeArchivo(const string& nitBuscado);
};

