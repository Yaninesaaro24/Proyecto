#include "Ubicacion.h"
#include <iostream>

using namespace std;

Ubicacion::Ubicacion() : anilloInicio(0), anilloFin(0) {}

void Ubicacion::registrarUbicacion() {
    cout << "Ingrese la zona (Norte, Sur, Este, Oeste): ";
    cin >> zona;
    cout << "Ingrese el anillo inicial (1-12): ";
    cin >> anilloInicio;
    cout << "Ingrese el anillo final (1-12): ";
    cin >> anilloFin;
    cout << "Ingrese la calle: ";
    cin.ignore();
    getline(cin, calle);
    cout << "Ingrese la avenida: ";
    getline(cin, avenida);
}

string Ubicacion::getZona() const {
    return zona;
}

int Ubicacion::getAnilloInicio() const {
    return anilloInicio;
}

int Ubicacion::getAnilloFin() const {
    return anilloFin;
}

string Ubicacion::getCalle() const {
    return calle;
}

string Ubicacion::getAvenida() const {
    return avenida;
}

void Ubicacion::setZona(const string& zona) {
    this->zona = zona;
}

void Ubicacion::setAnilloInicio(int anilloInicio) {
    this->anilloInicio = anilloInicio;
}

void Ubicacion::setAnilloFin(int anilloFin) {
    this->anilloFin = anilloFin;
}

void Ubicacion::setCalle(const string& calle) {
    this->calle = calle;
}

void Ubicacion::setAvenida(const string& avenida) {
    this->avenida = avenida;
}
