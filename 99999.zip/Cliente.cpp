#include "Cliente.h"
#include <iostream>
#include <fstream>

using namespace std;

Cliente::Cliente(const string& nombreUsuario, const string& contrasena, const string& tipo)
    : nombreUsuario(nombreUsuario), contrasena(contrasena), tipo(tipo), siguiente(nullptr) {}

Cliente::~Cliente() {}

void Cliente::guardarCliente() const {
    ofstream archivo("clientes.txt", ios::app);
    if (archivo.is_open()) {
        archivo << nombreUsuario << endl;
        archivo << contrasena << endl;
        archivo << tipo << endl;
        archivo.close();
    }
    else {
        cout << "No se pudo abrir el archivo para guardar el cliente" << endl;
    }
}

bool Cliente::existeCliente(const string& nombreUsuario) const {
    ifstream archivo("clientes.txt");
    if (archivo.is_open()) {
        string linea;
        while (getline(archivo, linea)) {
            if (linea == nombreUsuario) {
                archivo.close();
                return true;
            }
        }
        archivo.close();
    }
    return false;
}

bool Cliente::registrarCliente() {
    if (existeCliente(nombreUsuario)) {
        cout << "El nombre de usuario ya existe. Por favor, elija otro." << endl;
        return false;
    }
    guardarCliente();
    return true;
}

bool Cliente::iniciarSesion(const string& nombreUsuario, const string& contrasena) {
    ifstream archivo("clientes.txt");
    if (archivo.is_open()) {
        string linea;
        while (getline(archivo, linea)) {
            if (linea == nombreUsuario) {
                getline(archivo, linea);
                if (linea == contrasena) {
                    archivo.close();
                    return true;
                }
            }
        }
        archivo.close();
    }
    return false;
}

string Cliente::getTipo() const {
    return tipo;
}

string Cliente::getNombreUsuario() const {
    return nombreUsuario;
}

Cliente* Cliente::getSiguiente() const {
    return siguiente;
}

void Cliente::setSiguiente(Cliente* siguiente) {
    this->siguiente = siguiente;
}

void Cliente::buscarProductos() {
    BuscarProductos buscarProductos;
    buscarProductos.buscar();
}

void Cliente::buscarServicios() {
    BuscarServicios buscarServicios;
    buscarServicios.buscar();
}

void Cliente::controlMantenimientoPreventivo() {
    ControlMantenimientoPreventivo controlMantenimiento;
    controlMantenimiento.menuControlMantenimiento();
}

void Cliente::cuentaPremium() {
    Pago pago;
    if (pago.realizarPago()) {
        cout << "Cuenta premium activada." << endl;
    }
    else {
        cout << "El pago ha fallado. No se pudo activar la cuenta premium." << endl;
    }
}
