#pragma once
#include <string>

using namespace std;

class BuscarProductos {
public:
    void buscar() const;
    void filtrarPorPrecio() const;
    void filtrarPorUbicacion() const;
};
