#include "RegistroEmpresa.h"
#include <iostream>
#include <fstream>

using namespace std;

RegistroEmpresa::RegistroEmpresa() {}

void RegistroEmpresa::registrarEmpresa() {
    cout << "Ingrese el nombre de la empresa: ";
    cin.ignore();
    getline(cin, nombre);
    cout << "Ingrese el NIT de la empresa: ";
    cin >> nit;
    cout << "Ingrese el tipo de empresa: ";
    cin.ignore();
    getline(cin, tipoEmpresa);

    ubicacion.registrarUbicacion();

    guardarEnArchivo();
}

void RegistroEmpresa::mostrarEmpresa() const {
    cout << "Nombre: " << nombre << endl;
    cout << "NIT: " << nit << endl;
    cout << "Tipo de Empresa: " << tipoEmpresa << endl;
    cout << "Zona: " << ubicacion.getZona() << endl;
    cout << "Anillo Inicial: " << ubicacion.getAnilloInicio() << endl;
    cout << "Anillo Final: " << ubicacion.getAnilloFin() << endl;
    cout << "Calle: " << ubicacion.getCalle() << endl;
    cout << "Avenida: " << ubicacion.getAvenida() << endl;
}

void RegistroEmpresa::modificarEmpresa() {
    cout << "Modificar datos de la empresa" << endl;
    cout << "1. Nombre" << endl;
    cout << "2. NIT" << endl;
    cout << "3. Tipo de Empresa" << endl;
    cout << "4. Ubicaci�n" << endl;
    cout << "Seleccione una opci�n: ";
    int opcion;
    cin >> opcion;

    switch (opcion) {
    case 1:
        cout << "Ingrese el nuevo nombre de la empresa: ";
        cin.ignore();
        getline(cin, nombre);
        break;
    case 2:
        cout << "Ingrese el nuevo NIT de la empresa: ";
        cin >> nit;
        break;
    case 3:
        cout << "Ingrese el nuevo tipo de empresa: ";
        cin.ignore();
        getline(cin, tipoEmpresa);
        break;
    case 4:
        ubicacion.registrarUbicacion();
        break;
    default:
        cout << "Opci�n no v�lida" << endl;
        return;
    }

    guardarEnArchivo();
}

void RegistroEmpresa::guardarEnArchivo() const {
    ofstream archivo("empresas.txt", ios::app);
    if (archivo.is_open()) {
        archivo << nombre << endl;
        archivo << nit << endl;
        archivo << tipoEmpresa << endl;
        archivo << ubicacion.getZona() << endl;
        archivo << ubicacion.getAnilloInicio() << endl;
        archivo << ubicacion.getAnilloFin() << endl;
        archivo << ubicacion.getCalle() << endl;
        archivo << ubicacion.getAvenida() << endl;
        archivo.close();
    }
    else {
        cout << "No se pudo abrir el archivo para guardar la empresa" << endl;
    }
}

bool RegistroEmpresa::cargarDesdeArchivo(const string& nitBuscado) {
    ifstream archivo("empresas.txt");
    if (archivo.is_open()) {
        string linea;
        while (getline(archivo, linea)) {
            if (linea == nitBuscado) {
                nit = linea;
                getline(archivo, nombre);
                getline(archivo, tipoEmpresa);
                string zona;
                int anilloInicio, anilloFin;
                string calle, avenida;
                getline(archivo, zona);
                archivo >> anilloInicio >> anilloFin;
                archivo.ignore();
                getline(archivo, calle);
                getline(archivo, avenida);
                ubicacion.setZona(zona);
                ubicacion.setAnilloInicio(anilloInicio);
                ubicacion.setAnilloFin(anilloFin);
                ubicacion.setCalle(calle);
                ubicacion.setAvenida(avenida);
                archivo.close();
                return true;
            }
        }
        archivo.close();
    }
    return false;
}
