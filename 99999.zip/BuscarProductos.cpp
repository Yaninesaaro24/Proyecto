#include "BuscarProductos.h"
#include <iostream>
#include <fstream>
#include <sstream>

using namespace std;

void BuscarProductos::buscar() const {
    ifstream archivo("productos.txt");
    if (!archivo.is_open()) {
        cout << "No se pudo abrir el archivo de productos." << endl;
        return;
    }

    string linea;
    while (getline(archivo, linea)) {
        stringstream ss(linea);
        string categoria, subcategoria, nombreProducto, nombreEmpresa, zona, calle, avenida;
        double precio;
        int anilloInicio, anilloFin;

        getline(ss, categoria, '|');
        getline(ss, subcategoria, '|');
        getline(ss, nombreProducto, '|');
        ss >> precio;
        ss.ignore();
        getline(ss, nombreEmpresa, '|');
        getline(ss, zona, '|');
        ss >> anilloInicio >> anilloFin;
        ss.ignore();
        getline(ss, calle, '|');
        getline(ss, avenida);

        cout << "========================================\n";
        cout << "Categoria: " << categoria << endl;
        cout << "Subcategoria: " << subcategoria << endl;
        cout << "Producto: " << nombreProducto << endl;
        cout << "Precio: " << precio << endl;
        cout << "Empresa: " << nombreEmpresa << endl;
        cout << "Ubicacion: " << zona << ", Calle " << calle << ", Avenida " << avenida << ", Anillo " << anilloInicio << "-" << anilloFin << endl;
        cout << "========================================\n";
    }

    archivo.close();
}
